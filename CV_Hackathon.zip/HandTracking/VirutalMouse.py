import cv2
import numpy as np
import HandModule as htm
import time

import mouse
import pyautogui

from screeninfo import get_monitors
wCam , hCam = 640,480
pTime =0

smoothening =10
plocX,plocY =0,0
clocX,clocY=0,0

cap =cv2.VideoCapture(0)
cap.set(3,wCam)  #prop id for width is 3
cap.set(4,hCam) # prop id for height is 4

detector = htm.handDetector(maxHands=1)

wScreen =0
hScreen =0
for monitor in get_monitors():
    print(f"Width: {monitor.width}, Height: {monitor.height}")
    wScreen = monitor.width
    hScreen = monitor.height

print(wScreen,hScreen)
while True:

    success, img = cap.read()
    img = detector.findHands(img)

    lmList = detector.findPosition(img)
    ## 2. Get tip of index and middle fingers

    if len(lmList)!=0:
        # print(lmList[4],lmList[8])
        x1,y1 =lmList[8][1:]
        x2,y2 =lmList[12][1],lmList[12][2]

        cv2.circle(img,(x1,y1),10,(255,4,255),cv2.FILLED)
        cv2.circle(img,(x2,y2),10,(255,4,255),cv2.FILLED)
        
        ## 3. check which fingers are up
        fingers = detector.fingersUp()
        print(fingers)

        ## 4. Check if it is in moving mode : only index up
        if fingers[1]==1 and fingers[2] ==0: ##index up and middle down

            x3 =np.interp(x1,(0,wCam),(0,wScreen))
            y3 =np.interp(y1,(0,hCam),(0,hScreen))

            clocX =plocX+(x3-plocX)/smoothening
            clocY =plocY+(y3-plocY)/smoothening

        ##7. move mouse
            mouse.move(wScreen-clocX,clocY) 

            cv2.circle(img,(x1,y1),15,(0,0,255),cv2.FILLED)
            plocY,plocX =clocY,clocX

        if fingers[1]==1 and fingers[2] ==1: ##index up and middle down
            length, img, lineInfo = detector.findDistance(8, 12, img)
            print(length)
            # 10. Click mouse if distance short
            if length < 20:
                cv2.circle(img, (lineInfo[4], lineInfo[5]),
                15, (0, 255, 0), cv2.FILLED)
                mouse.click()
    

    cTime= time.time()
    fps = 1/(cTime-pTime)
    pTime=cTime

    cv2.imshow("Image", img)
    cv2.putText(img,str(int(fps)),(10,70),cv2.FONT_HERSHEY_PLAIN,3,(255,0,255),3)   

    cv2.waitKey(1)




    ##steps:
    
    
    ## 5. if only index up, convert coordinates from the width of our cam to screen 
    ## 6. smoothen values
    ##7. move mouse
    ##8. Check if clicking mode
    ## 9. Find distance between finger
    ## 10. click mouse if distance is short