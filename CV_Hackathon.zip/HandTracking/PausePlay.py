import cv2
import HandModule as hmt
import time
import pyautogui

cap = cv2.VideoCapture(0)

pTime =0

paused = False


detector = hmt.handDetector(detectionConfidence=0.7)

while True:

    success, img = cap.read()
    img = detector.findHands(img)

    lmList = detector.findPosition(img,draw=False)
    if len(lmList) != 0:
        fingers = detector.fingersUp()

        if fingers == [0, 0, 0, 0, 0]:
            if not paused:
                pyautogui.press("space")
            paused = True
        if fingers == [0, 1, 0, 0, 0]:
            pyautogui.press("right")
        if fingers == [0, 1, 1, 0, 0]:
            pyautogui.press("left")
        elif fingers == [1, 1, 1, 1, 1]:
            if paused:
                pyautogui.press("space")
            paused = False
 
    cTime= time.time()
    fps = 1/(cTime-pTime)
    pTime=cTime

    cv2.imshow("Image", img)
    cv2.putText(img,str(int(fps)),(10,70),cv2.FONT_HERSHEY_PLAIN,3,(255,0,255),3)



    # Exit the loop when the 'q' key is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

